cd C:\xampp\htdocs\prenter-pro\frontend
npm install
npm run dev
