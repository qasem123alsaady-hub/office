<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// معالجة طلبات OPTIONS (Preflight)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

// الحصول على البيانات المدخلة
$input = json_decode(file_get_contents("php://input"), true);

// الحصول على معرف من query string إذا كان موجوداً
$id = isset($_GET['id']) ? $_GET['id'] : '';

switch($method) {
    case 'GET':
        handleGet($db, $_GET);
        break;
    case 'POST':
        handlePost($db, $input);
        break;
    case 'PUT':
        handlePut($db, $id, $input);
        break;
    case 'DELETE':
        handleDelete($db, $id);
        break;
    default:
        http_response_code(405);
        echo json_encode(["message" => "Method not allowed", "success" => false]);
        break;
}

function handleGet($db, $params) {
    try {
        // بناء الاستعلام بناءً على المعلمات
        if (isset($params['customer_id'])) {
            $query = "SELECT * FROM projects WHERE customer_id = :customer_id ORDER BY created_at DESC";
            $stmt = $db->prepare($query);
            $stmt->bindParam(":customer_id", $params['customer_id']);
        } else if (isset($params['id'])) {
            $query = "SELECT * FROM projects WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(":id", $params['id']);
        } else {
            $query = "SELECT * FROM projects ORDER BY created_at DESC";
            $stmt = $db->prepare($query);
        }
        
        $stmt->execute();
        $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // إضافة المسميات القديمة للتوافق مع الواجهة الأمامية والتقارير
        foreach ($vehicles as &$vehicle) {
            $vehicle['make'] = $vehicle['project_name'];
            $vehicle['model'] = $vehicle['location'];
            $vehicle['license_plate'] = $vehicle['file_number'];
            $vehicle['year'] = $vehicle['contract_year'];
        }
        
        echo json_encode($vehicles);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "message" => "Error fetching vehicles", 
            "success" => false, 
            "error" => $e->getMessage()
        ]);
    }
}

function handlePost($db, $input) {
    try {
        // تعيين المتغيرات مع دعم المسميات القديمة (make/model) والمسميات الجديدة
        $project_name = $input['project_name'] ?? $input['make'] ?? null;
        $location = $input['location'] ?? $input['model'] ?? null;
        $file_number = $input['file_number'] ?? $input['license_plate'] ?? $input['licensePlate'] ?? null;
        $customer_id = $input['customer_id'] ?? null;
        $contract_year = $input['contract_year'] ?? $input['year'] ?? date('Y');
        $status = $input['status'] ?? 'pending';

        // التحقق من البيانات المطلوبة
        if (!$project_name || !$location || !$file_number || !$customer_id) {
                http_response_code(400);
                echo json_encode(["message" => "Missing required fields", "success" => false]);
                return;
            }

        // التحقق من عدم وجود مشروع بنفس رقم الملف
        $checkQuery = "SELECT id FROM projects WHERE file_number = :file_number";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(":file_number", $file_number);
        $checkStmt->execute();
        
        if ($checkStmt->rowCount() > 0) {
            http_response_code(400);
            echo json_encode([
                "message" => "رقم الملف/المحضر مسجل مسبقاً", 
                "success" => false,
                "error_code" => "FILE_NUMBER_EXISTS"
            ]);
            return;
        }

        // إضافة المشروع
        $query = "INSERT INTO projects (id, project_name, location, contract_year, file_number, status, customer_id, created_at) 
                  VALUES (:id, :project_name, :location, :contract_year, :file_number, :status, :customer_id, NOW())";
        $stmt = $db->prepare($query);
        
        $projectId = 'p' . time() . rand(1000, 9999);
        
        $stmt->bindParam(":id", $projectId);
        $stmt->bindParam(":project_name", $project_name);
        $stmt->bindParam(":location", $location);
        $stmt->bindParam(":contract_year", $contract_year);
        $stmt->bindParam(":file_number", $file_number);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":customer_id", $customer_id);
        
        if ($stmt->execute()) {
            // جلب بيانات المشروع المضاف
            $getQuery = "SELECT * FROM projects WHERE id = :id";
            $getStmt = $db->prepare($getQuery);
            $getStmt->bindParam(":id", $projectId);
            $getStmt->execute();
            $project = $getStmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode([
                "message" => "تم إضافة المشروع بنجاح", 
                "success" => true,
                "id" => $projectId,
                "project" => $project
            ]);
        } else {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Database error: " . $errorInfo[2]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "message" => "Server error", 
            "success" => false,
            "error" => $e->getMessage()
        ]);
    }
}

function handlePut($db, $id, $input) {
    try {
        if(empty($id)) {
            http_response_code(400);
            echo json_encode(["message" => "Missing project ID", "success" => false]);
            return;
        }

        // تعيين المسميات القديمة إلى الجديدة للتحديث لضمان التوافق
        $fieldMapping = [
            'make' => 'project_name',
            'model' => 'location',
            'license_plate' => 'file_number',
            'licensePlate' => 'file_number',
            'year' => 'contract_year'
        ];
        foreach ($fieldMapping as $old => $new) {
            if (isset($input[$old]) && !isset($input[$new])) {
                $input[$new] = $input[$old];
            }
        }

        $updateFields = [];
        $updateParams = [];
        
        $allowedFields = ['project_name', 'location', 'contract_year', 'file_number', 'status', 'customer_id'];
        
        foreach ($allowedFields as $field) {
            if (isset($input[$field])) {
                $updateFields[] = "$field = :$field";
                $updateParams[":$field"] = $input[$field];
            }
        }
        
        if (empty($updateFields)) {
            http_response_code(400);
            echo json_encode(["message" => "No fields to update", "success" => false]);
            return;
        }
        
        $query = "UPDATE projects SET " . implode(', ', $updateFields) . ", updated_at = NOW() WHERE id = :id";
        $updateParams[":id"] = $id;
        
        $stmt = $db->prepare($query);
        
        foreach ($updateParams as $key => $value) {
            $stmt->bindValue($key, $value);
        }

        if($stmt->execute()) {
            echo json_encode([
                "message" => "تم تحديث بيانات المشروع بنجاح", 
                "success" => true,
                "affected_rows" => $stmt->rowCount()
            ]);
        } else {
            $errorInfo = $stmt->errorInfo();
            http_response_code(500);
            echo json_encode([
                "message" => "Database error", 
                "success" => false,
                "error" => $errorInfo[2]
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "message" => "Server error", 
            "success" => false,
            "error" => $e->getMessage()
        ]);
    }
}

function handleDelete($db, $id) {
    try {
        if(empty($id)) {
            http_response_code(400);
            echo json_encode(["message" => "Missing project ID", "success" => false]);
            return;
        }

        // البدء بمعاملة قاعدة البيانات
        $db->beginTransaction();

        try {
            // 1. حذف جميع الخدمات المرتبطة بالمشروع
            $deleteServicesQuery = "DELETE FROM services WHERE project_id = :project_id";
            $deleteServicesStmt = $db->prepare($deleteServicesQuery);
            $deleteServicesStmt->bindParam(":project_id", $id);
            $deleteServicesStmt->execute();
            
            $deletedServicesCount = $deleteServicesStmt->rowCount();

            // 2. حذف المشروع نفسه
            $deleteProjectQuery = "DELETE FROM projects WHERE id = :id";
            $deleteProjectStmt = $db->prepare($deleteProjectQuery);
            $deleteProjectStmt->bindParam(":id", $id);
            $deleteProjectStmt->execute();
            
            $deletedProject = $deleteProjectStmt->rowCount() > 0;
            
            if ($deletedProject) {
                // تأكيد المعاملة
                $db->commit();
                
                echo json_encode([
                    "message" => "تم حذف المشروع والخدمات المرتبطة به بنجاح", 
                    "success" => true,
                    "deleted_services" => $deletedServicesCount,
                    "deleted_project" => true
                ]);
            } else {
                // التراجع عن المعاملة إذا لم يتم حذف المركبة
                $db->rollBack();
                
                http_response_code(404);
                echo json_encode([
                    "message" => "المشروع غير موجود", 
                    "success" => false
                ]);
            }
            
        } catch (Exception $e) {
            // التراجع عن المعاملة في حالة حدوث خطأ
            $db->rollBack();
            throw $e;
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "message" => "Server error: " . $e->getMessage(), 
            "success" => false,
            "error" => $e->getMessage()
        ]);
    }
}
?>