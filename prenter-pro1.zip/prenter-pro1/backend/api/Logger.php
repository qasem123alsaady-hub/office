<?php
class Logger {
    private $conn;
    private $table_name = "audit_logs";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function log($userId, $action, $tableName, $recordId, $oldValues = null, $newValues = null) {
        try {
            $query = "INSERT INTO " . $this->table_name . " 
                      SET user_id = :user_id, 
                          action = :action, 
                          table_name = :table_name, 
                          record_id = :record_id, 
                          old_values = :old_values, 
                          new_values = :new_values, 
                          ip_address = :ip_address, 
                          user_agent = :user_agent";

            $stmt = $this->conn->prepare($query);

            // الحصول على IP و User Agent
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

            // تحويل المصفوفات إلى JSON
            $oldJson = $oldValues ? json_encode($oldValues, JSON_UNESCAPED_UNICODE) : null;
            $newJson = $newValues ? json_encode($newValues, JSON_UNESCAPED_UNICODE) : null;

            // تنظيف المدخلات
            $action = htmlspecialchars(strip_tags($action));
            $tableName = htmlspecialchars(strip_tags($tableName));
            $recordId = htmlspecialchars(strip_tags($recordId));

            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':action', $action);
            $stmt->bindParam(':table_name', $tableName);
            $stmt->bindParam(':record_id', $recordId);
            $stmt->bindParam(':old_values', $oldJson);
            $stmt->bindParam(':new_values', $newJson);
            $stmt->bindParam(':ip_address', $ip);
            $stmt->bindParam(':user_agent', $userAgent);

            return $stmt->execute();
        } catch (Exception $e) {
            // في حالة فشل التسجيل، نكتفي بتسجيل الخطأ في ملف السيرفر ولا نوقف العملية الأصلية
            error_log("Audit Log Error: " . $e->getMessage());
            return false;
        }
    }
}
?>